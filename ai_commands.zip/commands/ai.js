const axios = require('axios');
const { sendText } = require('../utils/helpers');

module.exports = async (sock, msg, command, args, from) => {
  switch (command) {
    case 'gpt3':
      const prompt = args.join(' ');
      const gptRes = `Waa jawaab tijaabo ah oo GPT-3: "${prompt}"`; // Ku xir OpenAI haddii aad rabto
      await sendText(sock, from, gptRes);
      break;

    case 'gemini':
      const geminiInput = args.join(' ');
      const geminiRes = `Gemini jawaab tijaabo ah: "${geminiInput}"`; // Ku xir Google Gemini API haddii loo baahdo
      await sendText(sock, from, geminiRes);
      break;

    case 'randomwallpaper':
      await sock.sendMessage(from, {
        image: { url: 'https://source.unsplash.com/random/800x600/?wallpaper' },
        caption: 'Random Wallpaper'
      });
      break;

    case 'random':
      const items = ['Baabuur', 'Shimbir', 'Computer', 'Guri', 'Bad', 'Qorrax'];
      const randomItem = items[Math.floor(Math.random() * items.length)];
      await sendText(sock, from, `Waxaan soo xushay: ${randomItem}`);
      break;

    case 'applenews':
      await sendText(sock, from, 'News-ka Apple: https://www.apple.com/newsroom/');
      break;

    case 'nasanews':
      await sendText(sock, from, 'NASA News: https://www.nasa.gov/news/');
      break;

    case 'population':
      const country = args.join(' ') || 'Somalia';
      await sendText(sock, from, `${country} dadkeedu waa qiyaastii 17 million.`);
      break;

    default:
      await sendText(sock, from, `Amarka ${command} lama aqoonsan.`);
  }
};
